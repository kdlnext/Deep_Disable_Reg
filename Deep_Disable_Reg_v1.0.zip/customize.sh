ui_print "- Installing Deep_Disable_Reg v1.0 by kdlnext..."
ui_print "- Schedule: Deep scan & disable at 15s / 30s / 60s / 120s"
set_perm "$MODPATH/service.sh" 0 0 0755
ui_print "- Installation complete. Reboot to apply."
