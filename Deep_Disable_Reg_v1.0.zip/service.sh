#!/system/bin/sh
MODDIR=${0%/*}
LOGFILE="$MODDIR/disable.log"
TARGET_CACHE="$MODDIR/targets.list"

KEYWORDS="regservice|systemhelper|ctautoregist"

# Wait for system boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done

echo "=== $(date '+%Y-%m-%d %H:%M:%S') Deep_Disable_Reg v1.0 Started ===" > "$LOGFILE"

# Deep scan packages from 3 sources and disable matches
run_deep_disable() {
    ROUND_TAG="$1"
    echo "--- $(date '+%H:%M:%S') Scanning [$ROUND_TAG] ---" >> "$LOGFILE"

    {
        awk '{print $1}' /data/system/packages.list 2>/dev/null
        dumpsys package 2>/dev/null | grep -oE "Package \[[^]]+\]" | sed -E 's/Package \[|\]//g'
        pm list packages -u 2>/dev/null | sed 's/^package://'
    } | grep -iE "$KEYWORDS" | sort -u > "$TARGET_CACHE"

    [ ! -s "$TARGET_CACHE" ] && return

    while read -r pkg; do
        [ -z "$pkg" ] && continue
        # Core system package whitelist
        case "$pkg" in
            "android"|"com.android.systemui"|"com.android.settings"|"com.android.phone")
                continue
                ;;
        esac

        pm disable-user --user 0 "$pkg" >/dev/null 2>&1
        pm disable "$pkg" >/dev/null 2>&1
        cmd appops set "$pkg" RUN_IN_BACKGROUND ignore >/dev/null 2>&1
        cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1

        echo "$(date '+%H:%M:%S') [DISABLED] $pkg" >> "$LOGFILE"
    done < "$TARGET_CACHE"
}

# Round 1: 15s after boot
sleep 15
run_deep_disable "Boot +15s"

# Round 2: 30s after boot (15 + 15)
sleep 15
run_deep_disable "Boot +30s"

# Round 3: 60s after boot (30 + 30)
sleep 30
run_deep_disable "Boot +60s"

# Round 4: 120s after boot (60 + 60)
sleep 60
run_deep_disable "Boot +120s"

echo "=== $(date '+%Y-%m-%d %H:%M:%S') All 4 rounds completed, script exiting ===" >> "$LOGFILE"
exit 0
